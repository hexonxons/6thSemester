//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MFCHash.rc
//
#define IDD_MFCHASH_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_KEYWORD                     1000
#define IDC_BTNFIND                     1003
#define IDC_BTNADD                      1004
#define IDC_LIST1                       1007
#define IDC_LSTOUT                      1007
#define IDC_VALUE                       1008
#define IDC_KEYSEARCH                   1009
#define IDC_KEYDEL                      1010
#define IDC_BUTTON1                     1011
#define IDC_BTNDEL                      1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
